package com.example.publibrary.data

class DataMsg(
    val content: String = "",
) {
}