package com.example.library.demo.web.data;

public class DataContent {
    private String content;

    public DataContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
